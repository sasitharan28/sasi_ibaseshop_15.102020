import React,{Component} from 'react';

import { AppBar, Typography,CardActionArea,CardMedia,Paper,Divider,Link, } from '@material-ui/core';

import { Card, CardContent, Grid, FormControl, TextField, InputLabel, OutlinedInput, Pape, Box,Select, Button,CardActions } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import FacebookIcon from '@material-ui/icons/Facebook';
import BottomNavigation from '@material-ui/core/BottomNavigation';
import './css/product.css';
import Rating from 'material-ui-rating'
import {DataContext} from '../component/Data'
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';
import Alert from '@material-ui/lab/Alert';
import AlertTitle from '@material-ui/lab/AlertTitle';

import { ValidatorForm, TextValidator} from 'react-material-ui-form-validator';

import SignIn from './signIn';

import ApiService from "./../ApiService";



class Product extends Component {
    constructor(props){
      super(props)

      this.state={
          username:localStorage.getItem('username'),
          logInAlert:'none',

          productId: '',
          shopId: '',
          title:'',
          description: '',
          lastPrice: '',
          sellPrice: '',
          warranty: '',
          productRating: 0,
          stock: '',
          brand: '',
          model: '',
          category: '',
          date: '',

          image1:"",
          image2:"",
          image3:"",
          image4:"",
          image5:"",
          //this is shop data
          shopName: '',
          shopAddress: '',
          shopTelephone: '',
          shopLogo: '',
          shopRating: '',

          feedbacks:[],
          isFeedback:'',
          feedbackNum:0,

          quantity:1,


          newAvgRating:0,

          //img view set
          viewImg1:'',
          viewImg2:'',
          viewImg3:'',
          viewImg4:'',
          viewImg5:'',

          imgBtnBorder1:'1px solid black',
          imgBtnBorder2:'',
          imgBtnBorder3:'',
          imgBtnBorder4:'',
          imgBtnBorder5:'',

          userRating:3,
          userFeedback:'',
          nextOpacity:1,
          previewOpacity:0.7,

          pageNo:0,
          pageSize:5,
          feedback_pages:0,
          feedback_elements:0,
          feedback_current_page_no:0,
          previewDisabled:true,

          isBuy:'',

      };
    }
    //localStorage.setItem("hari","5f697e0d63723b695f7a0eb1");

    componentDidMount(){
      const productId = this.props.match.params.id;
      this.loadProduct(productId);
      this.isBuyProduct(productId)
    }
    loadProduct = (productId) => {
        ApiService.getProductById(productId)
            .then((res) => {
                let product = res.data;
                this.setState({
                  productId: product.productId,
                  shopId: product.shopId,
                  title: product.title,
                  description: product.description,
                  lastPrice: product.lastPrice,
                  sellPrice: product.sellPrice,
                  warranty: product.warranty,
                  productRating: product.rating,
                  stock: product.stock,
                  brand: product.brand,
                  model: product.model,
                  category: product.category,
                  date: product.date,

                  image1:product.image1,
                  image2:product.image2,
                  image3:product.image3,
                  image4:product.image4,
                  image5:product.image5,

                })
                this.loadShop();
                this.reloadFeedback();
                this.countFeedback();
            });

    }

    //this is get product shop Details
    loadShop = () =>{
      ApiService.getShopById(this.state.shopId)
          .then((res) => {
              let shops = res.data;
              this.setState({
                  shopName: shops.shopName,
                  shopAddress: shops.address,
                  shopTelephone: shops.telephone,
                  shopLogo: shops.shopLogo,
                  shopRating: shops.rating,
              })
          });
    }





reloadFeedback = () =>{
  ApiService.getFeedbackByProductId(this.state.productId,this.state.pageNo,this.state.pageSize)
      .then((res) => {
        let item=res.data.data;


        const feedback_pages = res.data.Total_no_of_pages;
        const feedback_elements = res.data.Total_no_of_elements;
        const feedback_current_page_no = res.data.Current_page_no;
        this.setState({
            feedback_pages : res.data.Total_no_of_pages,
            feedback_elements : res.data.Total_no_of_elements,
            feedback_current_page_no : res.data.Current_page_no,

        })

          //this.setState({feedbacks: res.data})
          if(item){
              {
                item.map(item =>(
                  ApiService.viewUserById(item.userId)
                      .then((res) => {

                          let feedbackerDetails = res.data;
                          this.setState(prevState => ({

                            feedbacks: [...prevState.feedbacks, {
                              "feedbackId":item.feedbackId,
                              "userId":item.userId,
                              "productId":item.productId,
                              "feedback":item.feedback,
                              "feedbackDate":item.feedbackDate,
                              "rating":item.rating,
                              "userName":feedbackerDetails.userName,

                            }]
                          }))
                      })
                ))
              }
              this.setState({
                  isFeedback:'yes',
              })
            }
            if(this.state.pageSize>=feedback_elements){
                this.setState({
                    nextOpacity:0.7,
                    nextDisabled:true,
                })
            }else {
                this.setState({
                    nextOpacity:1,
                    nextDisabled:false,
                })
            }
      });

}

countFeedback = () =>{
  ApiService.countFeedbackByProductId(this.state.productId)
      .then((res) => {
          if(res.data){
            this.setState({feedbackNum: res.data})
          }
      });
}


isBuyProduct=(productId)=>{
    ApiService.getOrderByProductId(productId)
        .then((res)=>{

            // this.setState({
            //     isBuy:res.data
            // })
            if(res.data){
                this.setState({
                    isBuy:'yes'
                })
            }

        })


}



  updateProduct=()=>{
      const oldFeedbackNum = this.state.feedbackNum-1;
      const subTotRat = oldFeedbackNum * this.state.productRating;
      const newFeedbackNum = this.state.feedbackNum;
      const tot = subTotRat+this.state.lastRating;
      const avgRate = tot/newFeedbackNum;
      const rat = this.state.feedbackNum-1 * this.state.productRating + this.state.userRating / this.state.feedbackNum;
      this.setState({
          newAvgRating:avgRate,
      })

      const product = {
          productId: this.state.productId,
          shopId: this.state.shopId,
          title: this.state.title,
          description: this.state.description,
          lastPrice: this.state.lastPrice,
          sellPrice: this.state.sellPrice,
          warranty: this.state.warranty,
          rating : avgRate,
          stock: this.state.stock,
          brand: this.state.brand,
          model: this.state.model,
          category: this.state.category,
          date: this.state.date,

          image1:this.state.image1,
          image2:this.state.image2,
          image3:this.state.image3,
          image4:this.state.image4,
          image5:this.state.image5,
      }
      ApiService.updateProduct(product)
          .then(res => {
              this.setState({
                  productRating:avgRate,
                  feedbacks:[],
              })
              this.reloadFeedback()
              // this.loadProduct(this.state.productId)
          })
  }





  handleChangeQuantity=(e) =>{
    this.setState({
      quantity:e.target.value,
    });
  }

  handleChange = (e) => {
      // this.setState({
      //     [e.target.name]:e.target.value,
      // })
      this.setState({[e.target.name]: e.target.value})
  }

  handleImgChange=(e) =>{
    if(e=='listImg1'){
        this.setState({
          viewImg1:'block',

          viewImg2:'none',
          viewImg3:'none',
          viewImg4:'none',
          viewImg5:'none',



          imgBtnBorder1:'1px solid black',

          imgBtnBorder2:'none',
          imgBtnBorder3:'none',
          imgBtnBorder4:'none',
          imgBtnBorder5:'none',
        });
    }else if (e=='listImg2'){
      this.setState({
        viewImg2:'block',

        viewImg1:'none',
        viewImg3:'none',
        viewImg4:'none',
        viewImg5:'none',


        imgBtnBorder2:'1px solid black',

        imgBtnBorder1:'none',
        imgBtnBorder3:'none',
        imgBtnBorder4:'none',
        imgBtnBorder5:'none',
      });
    }
    else if (e=='listImg3'){
      this.setState({
        viewImg3:'block',

        viewImg1:'none',
        viewImg2:'none',
        viewImg4:'none',
        viewImg5:'none',


        imgBtnBorder3:'1px solid black',

        imgBtnBorder2:'none',
        imgBtnBorder1:'none',
        imgBtnBorder4:'none',
        imgBtnBorder5:'none',
      });
    }
    else if (e=='listImg4'){
      this.setState({
        viewImg4:'block',

        viewImg1:'none',
        viewImg2:'none',
        viewImg3:'none',
        viewImg5:'none',


        imgBtnBorder4:'1px solid black',

        imgBtnBorder2:'none',
        imgBtnBorder3:'none',
        imgBtnBorder1:'none',
        imgBtnBorder5:'none',
      });
    }
    else if (e=='listImg5'){
      this.setState({
        viewImg5:'block',

        viewImg1:'none',
        viewImg2:'none',
        viewImg3:'none',
        viewImg4:'none',


        imgBtnBorder5:'1px solid black',

        imgBtnBorder2:'none',
        imgBtnBorder3:'none',
        imgBtnBorder4:'none',
        imgBtnBorder1:'none',
      });
    }
  }



      onChangeUsername = (e) => {
        this.setState({
          username: e.target.value
        });
      }

      onChangePassword = (e) => {
        this.setState({
          password: e.target.value
        });
      }




      buyItNowFun = (e) =>{
          {!this.state.username &&(
              this.setState({
                  logInAlert:`${e}`,
              })
          )}
      }

      changeRating = (e) =>{
          this.setState({
              userRating:e,
          })
      }

      resetFeedback = (e) =>{
          this.setState({
              userRating:3,
              userFeedback:'',
          })
      }

      putFeedback = () =>{
          const feedback = {
              userId:localStorage.getItem('userId'),
              productId:this.state.productId,
              feedback:this.state.userFeedback,
              rating:this.state.userRating,
          }
          ApiService.postFeedback(feedback)
          .then( res => {
              this.setState({
                  message:'Your feedback added successfully.',
                  alertTitle:'Success',
                  severity:'success',
                  lastRating:feedback.rating,
              })
              setTimeout( () => {
                  this.setState({
                      message:'',
                      alertTitle:'',
                      severity:'',
                      feedbacks:[],
                  })
                  this.updateProduct()
              },2500)

              this.resetFeedback()
              this.countFeedback()
          })
          .catch( err => {
            console.log(err);
              this.setState({
                  message:'Sorry your feedback added faield.',
                  alertTitle:'Error',
                  severity:'error',
              })
              setTimeout( () => {
                  this.setState({
                      message:'',
                      alertTitle:'',
                      severity:'',
                  })
              },2500)
          })
      }


      feedbackNextBtn=()=>{

          if(this.state.feedback_current_page_no < this.state.feedback_pages-1){

              this.setState({
                  pageNo:this.state.feedback_current_page_no+1,
                  previewDisabled:false,
                  previewOpacity:1,
              })

              setTimeout(()=>{
                  this.reloadFeedback()
                  this.setState({
                      feedbacks:[],
                  })
              },10)

              if(this.state.feedback_current_page_no+1 == this.state.feedback_pages-1){
                  this.setState({
                      nextOpacity:0.7,
                      nextDisabled:true,
                  })
              }
          }
      }

      feedbackPreviewBtn=()=>{
          if(this.state.feedback_current_page_no > 0){

              this.setState({
                  pageNo:this.state.feedback_current_page_no-1,
                  nextDisabled:false,
                  nextOpacity:1,
              })

              setTimeout(()=>{
                  this.reloadFeedback()
                  this.setState({
                      feedbacks:[],
                  })
              },10)

              if(this.state.feedback_current_page_no == 1){
                  this.setState({
                      previewDisabled:true,
                      previewOpacity:0.7,
                  })
              }

          }
      }



      // addItem(feedback){
      //     alert(feedback.userId);
      //     this.setState(prevState => ({
      //       items: [...prevState.items, {
      //         "id":this.state.items.length,
      //         "name":feedback.userId,
      //       }]
      //     }))
      // }


      static contextType = DataContext;


  render(){
    const {addCart,buythins,message,severity,alertTitle} = this.context;
    const feedbacks = this.state.feedbacks;
    // const message = this.state.message;
    // const alertTitle = this.state.alertTitle;
    // const severity = this.state.severity;

    return(
        <div>
        {message&&(
          <div>
              <Alert variant="filled" severity={severity} style={{position:"fixed",right:"100px",width:"550px",zIndex:"3",color:"white"}}>
                    <AlertTitle>{alertTitle}</AlertTitle>
                    {message}
              </Alert>
          </div>
        )}
        {this.state.message&&(
          <div>
              <Alert variant="filled" severity={this.state.severity} style={{position:"fixed",right:"100px",width:"550px",zIndex:"3",color:"white"}}>
                    <AlertTitle>{this.state.alertTitle}</AlertTitle>
                    {this.state.message}
              </Alert>
          </div>
        )}
            <div id="productMainDiv">
                <Paper id="productBox" elevation={3}>
                      <Grid container>


                            <Grid item xs={12} sm={12} md={6} lg={6} id="imgGrid">
                                  <Paper id='productImgBox' style={{marginTop:"20px"}} elevation={3}>
                                        <CardMedia
                                          Id='productImg1'
                                          component="img"
                                          image={this.state.image1}
                                          class="img-responsive"
                                          style={{display:this.state.viewImg1}}
                                        />
                                        <CardMedia
                                          Id='productImg2'
                                          component="img"
                                          image={this.state.image2}
                                          class="img-responsive"
                                          style={{display:this.state.viewImg2}}
                                        />
                                        <CardMedia
                                          Id='productImg3'
                                          component="img"
                                          image={this.state.image3}
                                          class="img-responsive"
                                          style={{display:this.state.viewImg3}}
                                        />
                                        <CardMedia
                                          Id='productImg4'
                                          component="img"
                                          image={this.state.image4}
                                          class="img-responsive"
                                          style={{display:this.state.viewImg4}}
                                        />
                                        <CardMedia
                                          Id='productImg5'
                                          component="img"
                                          image={this.state.image5}
                                          class="img-responsive"
                                          style={{display:this.state.viewImg5}}
                                        />
                                  </Paper>
                                  <Paper id="imgListBox" elevation={4}>
                                    <Button id="imgBtn1" onClick={() => this.handleImgChange('listImg1')}   style={{border:this.state.imgBtnBorder1}}>
                                      <CardMedia
                                        Id='listImg1'
                                        component="img"
                                        image={this.state.image1}
                                        class="img-responsive"

                                      />
                                    </Button>
                                    <Button id="imgBtn2" onClick={() => this.handleImgChange('listImg2')} style={{border:this.state.imgBtnBorder2}}>
                                      <CardMedia
                                        Id='listImg2'
                                        component="img"
                                        image={this.state.image2}
                                        class="img-responsive"

                                      />
                                    </Button>
                                    <Button id="imgBtn3" onClick={() => this.handleImgChange('listImg3')}   style={{border:this.state.imgBtnBorder3}}>
                                      <CardMedia
                                        Id='listImg3'
                                        component="img"
                                        image={this.state.image3}
                                        class="img-responsive"

                                      />
                                    </Button>
                                    <Button id="imgBtn4" onClick={() => this.handleImgChange('listImg4')} style={{border:this.state.imgBtnBorder4}}>
                                      <CardMedia
                                        Id='listImg4'
                                        component="img"
                                        image={this.state.image4}
                                        class="img-responsive"

                                      />
                                    </Button>
                                    <Button id="imgBtn5" onClick={() => this.handleImgChange('listImg5')} style={{border:this.state.imgBtnBorder5}}>
                                      <CardMedia
                                        Id='listImg5'
                                        component="img"
                                        image={this.state.image5}
                                        title="Contemplative Reptile"
                                        class="img-responsive"

                                      />
                                    </Button>
                                  </Paper>
                            </Grid>

                            <Grid item xs={12} sm={12} md={6} lg={6} id="productInfoGrid">
                                  <Paper id="productDetail" className="productDetail" elevation={0}>
                                      <Typography gutterBottom  id='producViewTitle' elevation={0} variant="h5">
                                        {this.state.title}
                                      </Typography>
                                      <Box id='reviewInfoDiv' elevation={0}>
                                          <Box gutterBottom  id='ratingDiv' elevation={0} >
                                              <Rating  value={this.state.productRating} readOnly style={{cursor:'pointer',width:'170px'}} title={this.state.productRating} /> <Link variant='span' id="reviewText" href="#feedbackMainDiv">{this.state.feedbackNum} Reviews</Link>
                                          </Box>
                                          <Typography gutterBottom  id='offer' elevation={0} variant="subtitle1">
                                              {this.state.lastPrice}
                                          </Typography>
                                          <Typography gutterBottom  id='sellPrice' elevation={0} variant="subtitle1">
                                              {this.state.sellPrice}
                                          </Typography>

                                          <Typography gutterBottom  id='warrantyDiv' elevation={0} variant="subtitle1">
                                            Warranty :- {this.state.warranty}
                                          </Typography>
                                          <Box gutterBottom  id='quantityDiv' elevation={0} variant="subtitle1">
                                            <Typography variant="span">Quantity :-</Typography>
                                              <FormControl variant="outlined" id="quantityIp">

                                                  <Select
                                                      Id="quantitySelect"
                                                      native
                                                      value={this.state.quantity}
                                                      onChange={this.handleChangeQuantity}
                                                      inputProps={{
                                                        name:'quantity',
                                                        id:'outline-quantity-native-simple'
                                                      }}
                                                  >
                                                      <option value={1}>1</option>
                                                      <option value={2}>2</option>
                                                      <option value={3}>3</option>
                                                      <option value={4}>4</option>
                                                      <option value={5}>5</option>
                                                      <option value={6}>6</option>
                                                      <option value={7}>7</option>
                                                      <option value={8}>8</option>
                                                      <option value={9}>9</option>
                                                      <option value={10}>10</option>
                                                  </Select>
                                              </FormControl>
                                          </Box>

                                      </Box>


                                      <Box id="buyBtnArea" elevation={0}>

                                          <Button Id="buyNowBtn" href={`/buynow?productId=${this.state.productId}&quantity=${this.state.quantity}`} >Buy Now</Button>

                                          <Button Id="addToCartBtn" onClick={()=> addCart(this.state.productId,this.state.quantity)} ><ShoppingCartIcon/>Add To Cart</Button>

                                      </Box>




                                      <Divider id='divider'/>
                                      <Box id='sellerInfoDiv' elevation={0}>
                                          <Typography gutterBottom  id='soldByText' elevation={0} variant="p">
                                              SOLD BY :
                                          </Typography>
                                          <Typography gutterBottom  id='soldShopName' elevation={0} variant="h6" >
                                              <Link href={"/shop/"+this.state.shopId} id="shopLink">{this.state.shopName}</Link>
                                          </Typography>
                                          <Rating name="read-only" value={this.state.shopRating} readOnly style={{cursor:'pointer',width:'170px',marginTop:'-15px'}} title={this.state.shopRating} />
                                          <Typography gutterBottom  id='soldShopAddress' elevation={0} variant="p">
                                              {this.state.shopAddress}
                                          </Typography>

                                          <Typography gutterBottom  id='soldShopRating' elevation={0} variant="p">

                                          </Typography>
                                      </Box>
                                  </Paper>

                            </Grid>

                      </Grid>

                </Paper>



                <Box id="loginAlertDivWaraper" style={{display:this.state.logInAlert}} onClick={() => this.buyItNowFun('none')} elevation={3}>
                </Box>

                <Paper id="loginAlertDiv" style={{}} style={{ display:this.state.logInAlert, left: `${window.innerWidth/2-300}px` }} >
                    <SignIn />
                </Paper>



                {/* Description and feedback area */}

                <Paper id="DescriptionDivWarraper" elevation="3">
                    <Grid container id="">
                          <Grid  item xs={12} >
                                <Typography id='descriptionHeading' variant="h5" id="desTitile" style={{marginLeft:'30px',marginTop:'20px'}}>Description</Typography>
                                <Box id="DescriptionDiv">
                                {this.state.description}
                                </Box>
                          </Grid>
                    </Grid>
                </Paper>


                {/*This is but feed Area*/}
            {this.state.isBuy&&(
                <Paper style={{width:'90%',margin:'auto',marginTop:'50px'}}>
                    <Box style={{width:'90%',margin:'auto',position:'relative',padding:'30px'}} >
                        <ValidatorForm onSubmit={this.putFeedback}>
                            <Typography variant="h5" >Rate the product</Typography>
                            <hr/>
                            <Rating name="product-rating"value={this.state.userRating} style={{}} onChange={(value) => this.changeRating(value)}/>
                            <TextValidator
                                label="User feedback"
                                variant="outlined"
                                style={{width:'100%',margin:'auto',marginTop:'20px',paddingBottom:'10px'}}
                                onChange={this.handleChange}
                                name="userFeedback"
                                validators={['required']}
                                errorMessages={['This field is required']}
                                value={this.state.userFeedback}
                                multiline
                                rows={4}
                            />
                            <Box style={{height:'40px'}}>
                              <Button type="reset" onClick={this.resetFeedback} style={{float:'right', height:'40px' , backgroundColor:'blue' , fontWeight:'bold' , color:'white'}}>Cancel</Button>
                              <Button type="submit" style={{float:'right', height:'40px' , backgroundColor:'blue' , marginRight:'20px' , fontWeight:'bold' , color:'white'}}>Submit</Button>
                            </Box>
                        </ValidatorForm>
                    </Box>
                </Paper>
            )}
                {/*feedback show area */}

                <Paper id="feedbackMainDiv" elevation="3">
                    <Grid container id="feedbackSection">
                        {this.state.isFeedback&&(
                            <Typography id='descriptionHeading' variant="h5" id="desTitile" style={{marginLeft:'30px',marginTop:'20px'}}>Rating And Feedbacks</Typography>
                        )}
                        {feedbacks.map(feedback =>(
                              <Paper  id="feedbackPaper" >
                                  <Grid container>
                                      <Grid  item xs={12} id="nameAndRatingDivGrid">
                                            <Box id="nameAndRatingDiv">
                                                <Typography id="raterName">{feedback.userName}</Typography>

                                                <Typography id="feedbackRating"><Rating name="read-only" value={feedback.rating} readOnly style={{}} /></Typography><Typography Id="feedbackRatingNumber">{feedback.rating}</Typography>
                                                <Typography id="ratingDate">{feedback.feedbackDate}</Typography>
                                            </Box>

                                            <Box id="feedbackDiv">
                                                <Typography id="feedbackText">{feedback.feedback}<br/><br/></Typography>
                                            </Box>
                                      </Grid>
                                  </Grid>
                              </Paper>
                        ))}

                        <Grid item xs={12}>
                          {this.state.isFeedback&&(
                            <Box style={{width:'90%',margin:'auto',height:'40px',paddingBottom:'20px'}}>
                                <Button style={{float:'right',marginRight:'20px',backgroundColor:'blue',fontWeight:'bold',color:'white',opacity:this.state.nextOpacity}} disabled={this.state.nextDisabled} onClick={this.feedbackNextBtn}>Next</Button>
                                <Typography style={{marginRight:'10px',marginLeft:'10px',marginTop:'7px',float:'right',fontWeight:'bold'}}>{this.state.feedback_current_page_no+1}</Typography>
                                <Button style={{float:'right',backgroundColor:'blue',fontWeight:'bold',color:'white',opacity:this.state.previewOpacity}} onClick={this.feedbackPreviewBtn} disabled={this.state.previewDisabled}>Preview</Button>
                            </Box>
                          )}
                          {!this.state.isFeedback&&(
                              <Box style={{height:'100px',width:'100%',marginTop:'30px'}}>
                                  <Typography variant="h4" style={{textAlign:'center'}}>No feedbacks</Typography>
                              </Box>
                          )}
                        </Grid>
                    </Grid>


                </Paper>
            </div>
            <br/><br/><br/><br/>
        </div>
    );
  }
}
export default Product;
