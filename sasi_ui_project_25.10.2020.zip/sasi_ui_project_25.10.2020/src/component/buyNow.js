import React, { Component } from 'react'

import {DataContext} from './Data'
import { ValidatorForm, TextValidator} from 'react-material-ui-form-validator';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';

// import Input from '@material-ui/core/Input';
import TextField from '@material-ui/core/TextField';
import Box from '@material-ui/core/Box';

import Alert from '@material-ui/lab/Alert';
import AlertTitle from '@material-ui/lab/AlertTitle';
import ApiService from "./../ApiService";




import {Grid,Paper,Card,CardContent,Typography,Button, CardActions,CardMedia,CardActionArea} from '@material-ui/core';

import './css/Payment.css';


export default class Payment extends Component {
    constructor(props){
      super(props)
      this.state={
        st:"",
        address:'',
        phone:'',
        email:'',
        userName:'',
        firstName:'',
        lastName:'',
        buyProductDetails:[],
        role:'',

        product:[],
        productId:'',
        quantity:'',

        image1:'',
        title:'',
        sellPrice:'',
        shopId:'',
        total:'',

        userDetailUpdated:"true",

        message:'',
        severity:'',
        alertTitle:'',
      }
    }

    static contextType = DataContext;

    componentDidMount(){
        this.loadUser()
        const authResult = new URLSearchParams(window.location.search);
        const productId =  authResult.get('productId');
        const quantity = authResult.get('quantity')
        this.setState({
            productId:productId,
            quantity:quantity,
        })
        setTimeout(() => {
            this.getProduct()
        },5)

    }

    loadUser = () => {
        ApiService.viewUserById(localStorage.getItem("userId"))
          .then(res =>{
              this.setState({
                userName:res.data.userName,
                address:res.data.address,
                emil:res.data.email,
                phone:res.data.phoneNumber,
                firstName:res.data.firstName,
                lastName:res.data.lastName,
                role:res.data.roles,
              })
          })
    }

    onChange = (e) => {
        this.setState({[e.target.name]: e.target.value})
        this.setState({
          userDetailUpdated:'false',
        })
    }


    getProduct(){

        ApiService.getProductById(this.state.productId)
        .then(res => {
            this.setState({
                product:res.data,
                image1:res.data.image1,
                title:res.data.title,
                sellPrice:res.data.sellPrice,
                shopId:res.data.shopId,
                // total:res.data.sellPrice+200,
            })
        })
    }



    // putOrder = () => {
    //   if (this.state.firstName =="" && this.state.lastName =="" && this.state.address =="" &&  this.state.phone =="" && this.state.userDetailUpdated == "true" ) {
    //         this.setState({
    //             message:"Plase fill your details first and  then click update button",
    //             severity:'error',
    //             AlertTitle:'Error',
    //         })
    //
    //         setTimeout(() => {
    //             this.setState({message:''})
    //         },3000)
    //
    //     } else{
    //
    //
    //
    //             const order = {
    //                 userId:localStorage.getItem("userId"),
    //                 buyProductDetails:[{
    //                     "buyProductId":this.state.productId,
    //                     "shopId":this.state.shopId,
    //                     "quantity":1,
    //                     "price":this.state.sellPrice,
    //                 }],
    //                 totalPrice:this.state.total,
    //             }
    //               ApiService.addOrder(order)
    //                 .then(res=>{
    //                       this.setState({
    //                           message:"Thank you for your purchase.",
    //                           severity:'success',
    //                           alertTitle:'Success',
    //                       })
    //                       setTimeout(() => {
    //                           window.location.href="/"
    //                           this.setState({
    //                               message:'',
    //                               severity:'',
    //                               alertTitle:'',
    //                           })
    //
    //                       },2500)
    //
    //                 })
    //                 .catch(err =>{
    //                     this.setState({
    //                         message:"Your purchase failed.",
    //                         severity:'error',
    //                         alertTitle:'Error',
    //                     })
    //                     setTimeout(() => {
    //                         this.setState({
    //                             message:'',
    //                             severity:'',
    //                             alertTitle:'',
    //                         })
    //                     },2500)
    //                 })
    //     }
    // }

    updateUser = () => {
        let user = {
            userId:localStorage.getItem("userId"),
            firstName:this.state.firstName,
            lastName:this.state.lastName,
            address:this.state.address,
            phoneNumber:this.state.phone,
            roles:this.state.role,
        }

        ApiService.userUpdate(user)
        .then(res => {
            // this.setState({
            //     severity:'success',
            //     alertTitle:'Success',
            //     message:"User detail updated..",
            //     userDetailUpdated:"true",
            // })
            //
            // setTimeout(() => {
            //     this.setState({message:''})
            //
            // },2500)
            const order = {
                userId:localStorage.getItem("userId"),
                buyProductDetails:[{
                    "buyProductId":this.state.productId,
                    "shopId":this.state.shopId,
                    "quantity":this.state.quantity,
                    "price":this.state.sellPrice,
                }],
                totalPrice:this.state.sellPrice * this.state.quantity + 200,
            }
              ApiService.addOrder(order)
                .then(res=>{
                      this.setState({
                          message:"Thank you for your purchase.",
                          severity:'success',
                          alertTitle:'Success',
                      })
                      setTimeout(() => {
                          window.location.href="/"
                          this.setState({
                              message:'',
                              severity:'',
                              alertTitle:'',
                          })

                      },2500)

                })
                .catch(err =>{
                    this.setState({
                        message:"Your purchase failed.",
                        severity:'error',
                        alertTitle:'Error',
                    })
                    setTimeout(() => {
                        this.setState({
                            message:'',
                            severity:'',
                            alertTitle:'',
                        })
                    },2500)
                })
        })

        .catch(error => {
            this.setState({
                severity:'error',
                alertTitle:'Error',
                message:"Update failed..",
            })

            setTimeout(() => {
                this.setState({message:''})
            },2500)
        })

    }



    render() {


        return(
          <div>
          {this.state.message&&(
            <div>
                <Alert variant="filled" severity={this.state.severity} style={{position:"fixed",right:"100px",width:"550px",zIndex:"3",color:"white"}}>
                      <AlertTitle>{this.state.alertTitle}</AlertTitle>
                      {this.state.message}
                </Alert>
            </div>
          )}
            <Paper id="paper1">
                <div className="payment_d">
                <ValidatorForm ref="form" onSubmit={this.updateUser}>
                    <div className="heading">
                        <h2>Order confirmation</h2>

                    </div>


                        <div className="boder">
                            <div className="detail_1">
                                <Grid container>
                                    <Grid item xs={12} md={6}>
                                        <Box className="box">
                                            <h3>Your Information</h3>
                                            <hr/>
                                            <TextValidator
                                                variant="outlined"
                                                label="First name"
                                                name="firstName"
                                                value={this.state.firstName}
                                                onChange={this.onChange}
                                                style={{width:'90%',display:'flex',margin:'auto',marginTop:'20px'}}
                                                validators={['required',]}
                                                errorMessages={['This field is required',]}
                                            />

                                            <TextValidator
                                                variant="outlined"
                                                label="Last name"
                                                name="lastName"
                                                value={this.state.lastName}
                                                onChange={this.onChange}
                                                style={{width:'90%',display:'flex',margin:'auto',marginTop:'20px'}}
                                                validators={['required',]}
                                                errorMessages={['This field is required',]}
                                            />

                                        </Box>
                                    </Grid>
                                    <Grid item xs={12} md={6}>
                                        <Box className="box">
                                            <h3>Shipping Address</h3>
                                            <hr/>
                                            <TextValidator
                                                variant="outlined"
                                                label="address"
                                                name="address"
                                                value={this.state.address}
                                                onChange={this.onChange}
                                                style={{width:'90%',display:'flex',margin:'auto',marginTop:'20px'}}
                                                validators={['required',]}
                                                errorMessages={['This field is required',]}
                                                multiline
                                                rows={4}
                                            />
                                        </Box>
                                    </Grid>
                                    <Grid item xs={12} md={6}>
                                        <Box className="box">
                                            <h3>Payment method</h3>
                                            <hr/>

                                            <RadioGroup aria-label="quiz" name="quiz" value="Cash On Delivery" style={{marginLeft:'5%'}} >
                                              <FormControlLabel value="Cash On Delivery" control={<Radio />} label="Cash On Delivery" cheked />
                                            </RadioGroup>
                                            {/* <input></input> */}
                                        </Box>
                                    </Grid>
                                    <Grid item xs={12} sm={6}>
                                        <Box className="box">
                                            <h3>Phone Number</h3>
                                            <hr/>
                                                <TextValidator
                                                    variant="outlined"
                                                    label="Phone number"
                                                    name="phone"
                                                    value={this.state.phone}
                                                    onChange={this.onChange}
                                                    style={{width:'90%',display:'flex',margin:'auto',marginTop:'20px'}}
                                                    validators={['required',]}
                                                    errorMessages={['This field is required',]}
                                                    type="number"
                                                />
                                        </Box>
                                    </Grid>
                                    {/*<Grid item xs={12} >
                                    <Button type="submit" id="EDIT_B">UPDATE</Button>
                                    </Grid>*/}
                                </Grid>
                            </div>
                        </div>

                        <div>
                              <Grid container>
                                  <Grid item xs={6} style={{textAlign:"center"}}><h3>Items</h3></Grid>
                                  <Grid item xs={3} style={{textAlign:"center"}}><p>Quantity</p></Grid>
                                  <Grid item xs={3} style={{textAlign:"center"}}><p>Price</p></Grid>

                              </Grid>
                              <div ><hr/>

                                          <div  >
                                              <Grid container>
                                                  <Grid item xs={6} style={{textAlign:"center"}}>
                                                      <Grid container>
                                                          <Grid item xs={4}>
                                                              <img src={this.state.image1} style={{width:"100px", height:"100px"}}></img>
                                                          </Grid>
                                                          <Grid item xs={4}>
                                                              <h2>{this.state.title}</h2>
                                                          </Grid>
                                                          <Grid item xs={4}></Grid>
                                                      </Grid>
                                                  </Grid>
                                                  <Grid item xs={3} style={{textAlign:"center"}}><p>{this.state.quantity}</p></Grid>
                                                  <Grid item xs={3} style={{textAlign:"center"}}>
                                                      <p>RS. {this.state.sellPrice}</p>
                                                  </Grid>

                                              </Grid>
                                              <br/>
                                              <hr/>
                                          </div>
                              </div>
                        </div>

                        <Grid container>
                            <Grid item item xs={12}>
                                <Box className="total_B">
                                    <div className="total_d">
                                        <div>
                                            <h4>Subtotal -  </h4>
                                            <h4>Shipping fee -  </h4>
                                            <h1>TOTAL -  </h1>
                                        </div>
                                        <div className="price_d">
                                            <h4>RS. {this.state.sellPrice * this.state.quantity}.00</h4>
                                            <h4>RS. 200.00</h4>
                                            <h1>  RS. {this.state.sellPrice * this.state.quantity + 200}.00</h1>
                                        </div>
                                    </div>
                                    <Button type="submit"  id="oderBtn">PLACE ORDER</Button>
                                </Box>
                            </Grid>
                        </Grid>
                </ValidatorForm>
                </div>
            </Paper>
          </div>
        )
    }
}
