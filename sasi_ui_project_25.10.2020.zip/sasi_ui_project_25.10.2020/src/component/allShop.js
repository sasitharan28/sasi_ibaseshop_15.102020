import React,{Component} from 'react';
import { Card, CardContent, Grid, FormControl, TextField, Input, FormHelperText, OutlinedInput ,Select ,CardActionArea } from '@material-ui/core';
import { Paper, Typography, AppBar, Toolbar, Button, IconButton ,Divider,Box,Link,CardMedia } from "@material-ui/core";
import { makeStyles } from '@material-ui/core/styles';
import InputLabel from '@material-ui/core/InputLabel';
import Rating from 'material-ui-rating'
import CreateIcon from '@material-ui/icons/Create';
import Close from '@material-ui/icons/Close';
import DeleteIcon from '@material-ui/icons/Delete';
import Alert from '@material-ui/lab/Alert';
import AlertTitle from '@material-ui/lab/AlertTitle';

import Logo from './../ibaseshopLogo.png'
import ApiService from "./../ApiService";
import './css/shopDetails.css';



class AllShop extends Component {
  constructor(props){
    super(props)
    this.state={
      shops:[],


      imagePreviewUrl1:'',

    }
  }





  componentDidMount() {
      this.loadAllShop();
  }

  loadAllShop = () => {
      ApiService.getAllShops()
          .then((res) => {
              this.setState({
                shops: res.data.data,
              });
          });
  }













  _handleImageChange1(e) {
    e.preventDefault();

    let reader1 = new FileReader();
    let file1 = e.target.files[0];

    reader1.onloadend = () => {
      this.setState({
        file1: file1,
        imagePreviewUrl1: reader1.result
      });
    }
    reader1.readAsDataURL(file1)
  }


  CancelFun = () => {
      window.location.href="/home"
  }


  render(){

    let {imagePreviewUrl1} = this.state;
    const shops=this.state.shops;


      return(
        <div>
            {this.state.message&&(
              <Alert variant="filled" severity={this.state.severity} style={{position:"fixed",right:"100px",width:"550px",zIndex:"3",color:"white"}}>
                    <AlertTitle>{this.state.alertTitle}</AlertTitle>
                    {this.state.message}
              </Alert>
            )}
              <div id="shopDetailsMainDiv">

                    {shops.map(shop =>(
                        <Grid container>
                            <Grid item xs={12}>
                              <Card id="shopDiv" key={shop.shopId}>
                                <Grid container>

                                    <Grid item xs={12} sm={12} md={4} style={{ width:'100%',height:'100%'}}>
                                        <div>
                                          {shop.shopLogo&&(
                                            <CardMedia
                                              component="img"
                                              image={shop.shopLogo}
                                              title="Shop Logo"
                                              class="img-responsive"
                                              id="shopPageLogo"
                                            />
                                          )}
                                          {!shop.shopLogo&&(
                                            <img src={Logo} id="shopPageLogo"/>
                                          )}
                                        </div>
                                    </Grid>

                                    <Grid item xs={12} sm={12} md={8}>
                                        <Typography variant="h4" id="shopTitle">
                                          {shop.shopName}
                                          <Rating name="read-only" value={shop.rating} size="small" size="small" readOnly   />
                                        </Typography>
                                    </Grid>

                                </Grid>
                              </Card>
                            </Grid>
                        </Grid>
                      ))
                    }

                    <Paper style={{backgroundColor:'white',height:'70px'}}>
                      <Box style={{float:'right',marginRight:'2%'}}>
                          <Button style={{marginTop:'20px',fontWeight:'bold',backgroundColor:'#03a9f4',color:'white',marginRight:'10px'}} onClick={() => this.CancelFun()}> <Close style={{marginRight:'5px'}}/> Cancel</Button>
                      </Box>
                    </Paper>




              </div>
        </div>
      )
  }
}
export default AllShop;
