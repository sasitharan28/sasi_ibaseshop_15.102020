import React, { Component } from 'react';

import Alert from '@material-ui/lab/Alert';
import AlertTitle from '@material-ui/lab/AlertTitle';
import {Grid,Paper,Card,CardContent,Typography,Button,Box} from '@material-ui/core';
import { ValidatorForm, TextValidator} from 'react-material-ui-form-validator';
import ApiService from "./../ApiService";

const style = {
    root: {

      marginTop: 30,
      height: 600,

    },
    Scard: {
        marginTop: 30,
        minHeight: 550,
    },
    STextFi: {
        width: 550
    }
}


class SignUp extends Component {
    constructor(props){
        super(props);

        this.state = {
            username:"",
            email:"",
            password:"",
            massage:"",
            message2:"",
            successfulUserName: false,
            successfulEmail: false,
            successfulPassword: false,
        }
    }


    componentDidMount() {
        // custom rule will have name 'isName'
        ValidatorForm.addValidationRule('isName', (value) => {
            if ((this.state.username.length) >3 && (this.state.username.length) <20){
                return true;
            }
            return false;
        });

        // custom rule will have name 'isPassword'
        ValidatorForm.addValidationRule('isPassword',(value) => {
            if ((this.state.password.length) > 6 && (this.state.password.length) < 40) {
                return true;
            }
            return false;
        });
    }

    componentWillUnmount() {
        // remove rule when it is not needed
        ValidatorForm.removeValidationRule('isName');
        ValidatorForm.removeValidationRule('isPassword');
    }


    onChangeUsername = (e) => {
        this.setState({
          username: e.target.value
        });
    }

    onChangeEmail = (e) => {
        this.setState({
            email: e.target.value
        });
    }

    onChangePassword = (e) => {
        this.setState({
            password: e.target.value
        });
    }

    handleRegister = (e) => {
        e.preventDefault();


        if ( (this.state.username.length) >3 && (this.state.username.length) <20 ) {
            this.setState({
                successfulUserName: true,
            })
        } else {
            this.setState({
                successfulUserName: false,
            })
        }


        var emailformat = /^\w+([-]?\w+)*@\w+([-]?\w+)*(\.\w{2,3})+$/;
        if(this.state.email.match(emailformat)) {
            this.setState({
                successfulEmail: true,
            })
        } else {
            this.setState({
                successfulEmail: false,
            })
        }


        if ( (this.state.password.length) > 6 && (this.state.password.length) < 40 ) {
            this.setState({
                successfulPassword: true,
            })
        } else {
            this.setState({
                successfulPassword: false,
            })
        }

        // if(this.state.successfulUserName && this.state.successfulEmail && this.state.successfulPassword) {
        //     console.log(this.state.username + " " + this.state.password + " " + this.state.email)
        //     this.setState({
        //       successful: true,
        //       message: "Registered successfully"
        //     })
        // } else {
        //     this.setState({
        //       successful: false,
        //     })
        // }


        ///////////////  api   /////////////
        let user = {
            userName : this.state.username,
            email : this.state.email,
            password : this.state.password
        }

        ApiService.register(user)
        .then((response) => {
                //console.log(response.data.message);
              this.setState({
                message: response.data.message,
                successful: true
              });
              setTimeout(() => {
                  this.setState({message:""})
                  this.props.history.push("/signin")
              },2500);
            })
        .catch((error) => {

            this.setState({
              successful: false,
              message2: error.response.data.message,

            });
            console.log("Error msg -",error.response.data.message);
            setTimeout(() => {
                this.setState({message2:""})
            },2500);
            // if(error.response.data.message){
            //     this.setState({
            //       successful: false,
            //       message2: error.response.data.message
            //     });
            // }else{
            //   this.setState({
            //     successful: false,
            //     message2: "Network error...."
            //   });
            // }
            // console.log("error :- " +error);
        })
    }


    render() {

        return(
            <div>
              {/*  {!this.state.successful ? (*/}
                  {this.state.message2&&(
                    <Alert variant="filled" severity="error" style={{position:"fixed",right:"100px",width:"550px",zIndex:"3",color:"white"}}>
                        <AlertTitle>Eror</AlertTitle>
                          {this.state.message2}
                    </Alert>
                  )}
                  {this.state.message&&(
                    <Alert variant="filled" severity="success" style={{position:"fixed",right:"100px",width:"550px",zIndex:"3",color:"white"}}>
                        <AlertTitle>Success</AlertTitle>
                          {this.state.message}
                    </Alert>
                  )}

                    <Grid container>

                        <Grid item xs={3}/>
                        <Grid item xs={6}>
                            <Box style={style.root}>
                                <Grid container>
                                    <Grid item xs={2}/>
                                    <Grid item xs={8}>
                                        <Card style={style.Scard}>
                                            <CardContent>
                                                <ValidatorForm
                                                    ref="form"
                                                    onSubmit={this.handleRegister}
                                                    onError={errors => console.log(errors)}
                                                >

                                                    <Typography variant='h3' style={{color:"#03a9f4",textAlign:"center"}}>
                                                        Register Account
                                                    </Typography> <br/>


                                                    <br/><br/>
                                                    <TextValidator
                                                        helperText="Plese enter username"
                                                        variant="outlined"
                                                        label="Username"
                                                        onChange={this.onChangeUsername}
                                                        name="Username"
                                                        value={this.state.username}
                                                        style={style.STextFi}
                                                        validators={['required','isName']}
                                                        errorMessages={['This field is required','The user username must be between 3 and 20 charactes']}
                                                    />

                                                    <br/><br/>

                                                    <TextValidator
                                                        helperText="Plese enter email"
                                                        variant="outlined"
                                                        label="Email"
                                                        onChange={this.onChangeEmail}
                                                        name="Email"
                                                        value={this.state.email}
                                                        style={style.STextFi}
                                                        validators={['required','isEmail']}
                                                        errorMessages={['This field is required','This is not a valid email!!']}
                                                    />

                                                    <br/><br/>

                                                    <TextValidator
                                                        helperText="Plese enter Password"
                                                        variant="outlined"
                                                        label="Password"
                                                        onChange={this.onChangePassword}
                                                        name="Password"
                                                        value={this.state.password}
                                                        style={style.STextFi}
                                                        validators={['required','isPassword']}
                                                        errorMessages={['This field is required','The user password must be between 6 and 40 charactes ']}
                                                        type="password"
                                                    />

                                                    <br/><br/>

                                                    <Button variant="contained" style={{backgroundColor:"#03a9f4",color:"white",fontWeight:"bold"}} type="submit">
                                                        SIGN UP
                                                    </Button>

                                                    <p>Already have an account?  <a href='/signin' style={{textDecoration:'none'}}>Sign in</a></p>
                                                    <br/><br/>
                                                </ValidatorForm>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                    <Grid item xs={2}/>
                                </Grid>
                            </Box>
                        </Grid>
                        <Grid item xs={3}/>
                    </Grid>

              {/*      ) : (

                    <Grid container>
                        <Grid item xs={4}/>
                        <Grid item xs={4}>
                          <div>
                              <div style={{width: '100%',height:'100%',position: 'fixed',top:'0px',left: '0px',backgroundColor: 'black',opacity: '0.9',zIndex: '2'}}>

                              </div>
                              <Alert variant="filled" severity={this.state.severity} style={{position: 'fixed',top:'300px',width: '550px',zIndex: '3',left: `${window.innerWidth/2-275}px`,color:'white'}}>
                                    <AlertTitle>Success</AlertTitle>
                                    {this.state.message}
                              </Alert>

                          </div>
                        </Grid>
                        <Grid item xs={4}/>
                    </Grid>
                    )
                } */}
        </div>
        )
    }
}
export default SignUp;
