import React,{Component} from 'react';
import { AppBar, Typography,CardActionArea,CardMedia,Paper,Divider } from '@material-ui/core';
import { Card, CardContent, Grid, FormControl, TextField, InputLabel, OutlinedInput, Pape, Box,Select, Button,CardActions } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import Rating from 'material-ui-rating';
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';
import {Link} from 'react-router-dom'


import {DataContext} from './Data';


import BottomNavigation from '@material-ui/core/BottomNavigation';
import Alert from '@material-ui/lab/Alert';
import AlertTitle from '@material-ui/lab/AlertTitle';

import './css/search.css';

import ApiService from "./../ApiService";










class Search extends Component {
  static contextType = DataContext;

  constructor(props) {
    super(props)
    this.state={
      minPrice:'',
      maxPrice:'',
      warranty:'',
      searchKey:'',

      products:[],

      Current_page_no:0,
      Total_no_of_pages:0,
      Total_no_of_elements:0,
      pageSize:12,
      pageNo:0,
      nxtOpacity:1,
      prwOpacity:0.7,
    };
  }

  componentDidMount(){
     this.setKeys()
  }
  setKeys = () => {
      const authResult = new URLSearchParams(window.location.search);
        if(authResult.get('searchKey') == "null"){
            const searchKey = "";
            const minPrice = authResult.get('minPrice');
            const maxPrice = authResult.get('maxPrice');
            const warranty = authResult.get('warranty');
            this.setState({
                minPrice:minPrice,
                maxPrice:maxPrice,
                warranty:warranty,
                searchKey:"",
            })
            this.loadProduct(searchKey,minPrice,maxPrice,warranty)
        }else {
            const searchKey = authResult.get('searchKey');
            const minPrice = authResult.get('minPrice');
            const maxPrice = authResult.get('maxPrice');
            const warranty = authResult.get('warranty');
            this.setState({
                minPrice:minPrice,
                maxPrice:maxPrice,
                warranty:warranty,
                searchKey:searchKey,
            })
            this.loadProduct(searchKey,minPrice,maxPrice,warranty)
        }
  }

  loadProduct = (searchKey,minPrice,maxPrice,warranty) => {
      ApiService.getProductBySearchKey(searchKey,minPrice,maxPrice,warranty,this.state.pageNo,this.state.pageSize)
      .then(res => {
          const products = res.data.data;
          console.log(res);
          this.setState({
              products:products,
              Current_page_no:res.data.Current_page_no,
              Total_no_of_pages:res.data.Total_no_of_pages,
              Total_no_of_elements:res.data.Total_no_of_elements,
          })
      })
  }


  // lds = () => {
  //
  //     ApiService.getProductBySearchKey(this.state.searchKey,this.state.minPrice,this.state.maxPrice,this.state.warranty)
  //     .then(res => {
  //         const products = res.data.data;
  //         this.setState({
  //             products:products,
  //         })
  //     })
  //     alert(this.state.searchKey)
  //     alert(this.state.minPrice)
  //     alert(this.state.maxPrice)
  //     alert(this.state.warranty)
  // }





  onChangeMinPrice = (e) =>{
    this.setState({
      minPrice:e.target.value,
    });
  }
  onChangeMaxPrice = (e) =>{
    this.setState({
      maxPrice:e.target.value,
    });
  }
  onChangeWarranty = (e) =>{
    this.setState({
      warranty:e.target.value,
    });
  }



  next = () => {
    if(this.state.Total_no_of_pages-1 > this.state.pageNo){

      this.setState({
        pageNo:this.state.pageNo+1,
        nxtDisabled:false,
        prwDisabled:false,
        prwOpacity:1,
        products:[],
      })
      setTimeout(() => {
            {this.setKeys()}
      },5);
    }else {
      this.setState({
        nxtDisabled:true,
        nxtOpacity:0.7,
      })
    }
  }



  preview = () => {
    if(this.state.Current_page_no > 0){
        this.setState({
            pageNo:this.state.pageNo-1,
            prwDisabled:false,
            nxtDisabled:false,
            nxtOpacity:1,
            products:[],
        })
        setTimeout(() => {
              {this.setKeys()}
        },5);
    }else {
        this.setState({
          prwDisabled:true,
          prwOpacity:0.7,
        })
      }
  }




  render(){
    const products = this.state.products;
    const {addCart,shops,buythins,message,severity,alertTitle} = this.context;



    return (
      <div>
      {message&&(
        <div>

            <Alert variant="filled" severity={severity} style={{position:"fixed",right:"100px",width:"550px",zIndex:"3",color:"white"}}>
                  <AlertTitle>{alertTitle}</AlertTitle>
                  {message}
            </Alert>
        </div>
      )}
        <div style={{position:'relative',top:'50px'}}>

          <div className='searchMainDiv' >
            <Grid container spacing={5} >
              <Grid item xs={3}  >
                <Box  className='priceBox'>
                <Typography className='sortTitle'>Price (RS)</Typography>
                  <FormControl variant="outlined" className='minPriceInput'>
                    <InputLabel htmlFor="component-outlined">Min Price</InputLabel>
                    <OutlinedInput id="component-outlined" value={this.state.minPrice} onChange={this.onChangeMinPrice} label="Min Price" type='number' />
                  </FormControl>
                  <FormControl variant="outlined" className='maxPriceInput'>
                    <InputLabel htmlFor="component-outlined">Max Price</InputLabel>
                    <OutlinedInput id="component-outlined" value={this.state.maxPrice} onChange={this.onChangeMaxPrice} label="Max Price" type='number' />
                  </FormControl>
                </Box>
              </Grid>

              <Grid item xs={3} >
                <Box  className='sortBox'>
                <Typography className='sortTitle'>Sort</Typography>
                <FormControl variant="outlined" className='sortSelect'>
                  <InputLabel htmlFor="outlined-age-native-simple">Sort</InputLabel>
                  <Select
                    native
                    value={this.state.gender}
                    onChange={this.handleChangeGender}
                    label="Sort"
                    inputProps={{
                      name: 'age',
                      id: 'outlined-age-native-simple',
                    }}
                  >

                    <option value={'Best Match'}>Best Match</option>
                    <option value={'Price: Hight to low'}>Price: Hight to low</option>
                    <option value={'Price: Low to Height'}>Price: Low to height</option>
                  </Select>
                </FormControl>
                </Box>
              </Grid>

              <Grid item xs={3} >
                <Box  className='warrantyBox'>
                <Typography className='sortTitle'>warranty (Month)</Typography>
                  <FormControl variant="outlined" className='warrantyInput'>
                    <InputLabel htmlFor="component-outlined">Warranty</InputLabel>
                    <OutlinedInput id="component-outlined" value={this.state.warranty} onChange={this.onChangeWarranty} label="warranty" type='number' />
                  </FormControl>

                </Box>
              </Grid>

              <Grid item xs={3}  >
                <Box  className='applyBtnBox'>
                  <Button variant="contained" style={{backgroundColor:'#03a9f4',color:'white'}} className='applyBtn' href={`/search?searchKey=${this.state.searchKey}&minPrice=${this.state.minPrice}&maxPrice=${this.state.maxPrice}&warranty=${this.state.warranty}`}>
                  <b>Apply</b>
                  </Button>
                </Box>
              </Grid>
            </Grid>

          </div>










          <div  className='searchResultDiv'>
            <Grid container >


            {products.map(product =>(
                  <Grid item xs={6} sm={4} md={3} lg={3} style={{marginTop:'20px'}}  >
                          <Card className='productCard' key={product.id}  elevation={3}>
                            <CardActionArea href={'/product/'+product.productId}>
                              <Box className='showImgDiv'>
                                <CardMedia
                                  className='showImg'
                                  component="img"
                                  image={product.image1}
                                  title="Contemplative Reptile"
                                  class="img-responsive"
                                  id="showImg"

                                />
                              </Box>
                              <CardContent>
                                <Typography gutterBottom  className='productTitle'>
                                {product.title}
                                </Typography>
                                <Typography className='offerPrice' variant="h6">
                                  {product.lastPrice}
                                </Typography>
                                  <Typography className='sellPrice' variant="h6">
                                  {product.sellPrice}
                                  </Typography>
                                  <Typography className='sellPrice' variant="h6">
                                  warranty {product.warranty} (Mo)
                                  </Typography>

                                  <Typography className='offerPrice'>
                                      <Rating name="read-only" value={product.rating} readOnly style={{}} />
                                  </Typography>
                              </CardContent>
                            </CardActionArea>
                            <CardActions >
                            <Button variant="contained" id="btn" style={{backgroundColor:'#03a9f4',color:'white',margin:'auto'}} href={`/buynow?productId=${product.productId}`} >
                            Buy now
                            </Button>
                            <Button variant="contained" onClick={()=> addCart(product.productId)} style={{backgroundColor:'#03a9f4',color:'white',margin:'auto'}} ><ShoppingCartIcon/>
                            Add to cart
                            </Button>


                            </CardActions>

                          </Card>
                  </Grid>
            ))}


            <Grid item xs={12} sm={12} md={12} lg={12}>
                <Paper style={{width:'100%',height:'60px',marginTop:'30px'}}>
                      <Box style={{position:'relative',top:'10px',height:'40px',width:'265px',margin:'auto'}}>


                        <Button disabled={this.state.prwDisabled} onClick={()=>this.preview()} style={{float:'left' ,backgroundColor:'#03a9f4',color:'black',fontWeight:'bold',marginRight:'10px',height:'40px',color:'white',opacity:this.state.prwOpacity}}  >preview</Button>
                              <Typography style={{float:'left',color:'black',fontWeight:'bold',marginRight:'10px',marginTop:'5px',width:'60px',textAlign:'center'}} variant='h6'>{this.state.Current_page_no+1}</Typography>
                        <Button disabled={this.state.nxtDisabled} onClick={()=>this.next()}  style={{float:'right',backgroundColor:'#03a9f4',color:'black',fontWeight:'bold',width:'100px',height:'40px',color:'white',opacity:this.state.nxtOpacity}}>Next</Button>


                      </Box>
                </Paper>
            </Grid>


            </Grid>
          </div>

        </div>
    </div>
    )
  }
}

export default Search;
