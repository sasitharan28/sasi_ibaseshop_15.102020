import React,{Component} from 'react';

import ApiService from './../ApiService.js'
import {Grid,Paper,Card,CardContent,Typography,Button, CardActions,CardMedia,CardActionArea,Box,Divider} from '@material-ui/core';

export class MyOrder extends Component {
  constructor(props) {
      super(props)
      this.state={
        orders:[],
        buyProductDetails:[],
      }
  }

  componentDidMount(){
      this.loadOrders()
  }




  loadOrders = () =>{
      ApiService.getOrderByUserId(localStorage.getItem("userId"))
        .then(res =>{
              let orders=res.data;

              {
                orders.map(item =>(
                  item.buyProductDetails.map(item2 =>(
                      ApiService.getProductById(item2.buyProductId)
                        .then(res => {
                          let product = res.data;
                            this.setState(prevState => ({
                              orders: [...prevState.orders, {
                                  "orderId":item.orderId,
                                  "userId":item.userId,
                                  "buyProductDetails":this.state.buyProductDetails,
                                  "totalPrice":item.totalPrice,
                                  "orderDateTime":item.orderDateTime,
                                  "buyProductId":item2.buyProductId,
                                  "quantity":item2.quantity,
                                  "price":item2.price,
                                  "title":product.title,
                                  "productId":product.productId,
                                  "image1":product.image1,
                              }]


                        }))
                      })


                  ))




                ))
              }

        })
        .catch(err => {
            console.log(err);
        })
  }




  render(){
      const orders = this.state.orders;


      return(
          <div>
              <div style={{position:'relative',top:'50px',width:'90%',backgroundColor:'white',margin:'auto'}}>
                  <div style={{position:'relative',top:'20px'}}>
                      <h1 style={{textAlign:'center'}}>My orders</h1>
                  </div>
                  <div style={{marginTop:'50px',paddingBottom:'50px',}}>
                    <Grid container style={{margin:'auto',backgroundColor:'#eee',padding:'20px'}}>
                        {/*<Grid item xs={3}>
                          <Typography style={{margin:'auto',textAlign:'center',fontWeight:'bold',fontSize:'23px'}}>order id</Typography>
                        </Grid>*/}
                        <Grid item xs={3}>
                          <Typography style={{margin:'auto',textAlign:'center',fontWeight:'bold',fontSize:'23px'}}>order Date</Typography>
                        </Grid>
                        <Grid item xs={3}>
                          <Typography style={{margin:'auto',textAlign:'center',fontWeight:'bold',fontSize:'23px'}}>Image</Typography>
                        </Grid>
                        <Grid item xs={3}>
                          <Typography style={{margin:'auto',textAlign:'center',fontWeight:'bold',fontSize:'23px'}}>Title</Typography>
                        </Grid>
                        <Grid item xs={3}>
                          <Typography style={{margin:'auto',textAlign:'center',fontWeight:'bold',fontSize:'23px'}}>Total</Typography>
                        </Grid>

                    </Grid>

                    {
                      orders.map(order => (

                        <Grid container style={{margin:'auto',backgroundColor:'white',padding:'20px',borderBottom:'1px solid black',}}>
                            {/*<Grid item xs={3} title={order.orderId}>
                                <Typography style={{margin:'auto',textAlign:'center',width:'90%',overflow:'hidden',textOverflow:'ellipsis'}} >
                                    <ul>
                                        <li style={{listStyleType:'none'}}>
                                            {order.orderId}
                                        </li>
                                    </ul>
                                </Typography>
                            </Grid>*/}
                            <Grid item xs={3} title={order.orderDateTime}>
                              <Typography style={{margin:'auto',textAlign:'center',wordBreak:'break-all',overflow:'hidden',textOverflow:'ellipsis',width:'90%'}}>
                                  <ul>
                                      <li style={{listStyleType:'none'}}>
                                          {order.orderDateTime}
                                      </li>
                                  </ul>
                              </Typography>
                            </Grid>
                            <Grid item xs={3}>
                              <Typography style={{margin:'auto',textAlign:'center'}}>

                                  <CardMedia
                                    component="img"
                                    image={order.image1}
                                    title="Contemplative Reptile"
                                    class="img-responsive"
                                    style={{maxWidth:'90%',maxHeight:'100px'}}

                                  />
                              </Typography>
                            </Grid>
                            <Grid item xs={3}>
                              <Typography style={{margin:'auto',textAlign:'center',width:'90%',overflow:'hidden',textOverflow:'ellipsis'}} >

                                  {/*{order.buyProductDetails.map((row2, index)=>(
                                    <ul key={index}>
                                        <li align="center" style={{overflow:'hidden',textOverflow:'ellipsis'}}>{row2.buyProductId}</li>
                                    </ul>
                                  ))}*/}
                                  <a href={'/product/'+order.productId} style={{textDecoration:'none',color:'black'}}>{order.title}</a>
                              </Typography>
                            </Grid>
                            <Grid item xs={3}>
                              <Typography style={{margin:'auto',textAlign:'center'}}>
                                  <ul>
                                      <li style={{listStyleType:'none'}}>
                                          {order.totalPrice}
                                      </li>
                                  </ul>
                              </Typography>
                            </Grid>

                        </Grid>

                      ))
                    }

                  </div>
              </div>
          </div>
      )
  }
}
export default MyOrder;
