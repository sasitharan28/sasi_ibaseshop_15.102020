import React, {Component} from 'react';
import logo from './logo.svg';
import './App.css';
import { Paper, Typography, AppBar, Toolbar, Button, IconButton } from "@material-ui/core";
import Rating from 'material-ui-rating';
import {Grid, CardActions,CardMedia, CardActionArea, Box, Card, CardContent, TextField} from '@material-ui/core';
import { AccountCircle } from "@material-ui/icons";
//import { BrowserRouter as Router, Switch, Route } from "react-router-dom";

import MenuIcon from '@material-ui/icons/Menu';
import SearchIcon from '@material-ui/icons/Search';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';
import LocationOnIcon from '@material-ui/icons/LocationOn';
import { Route, Link, BrowserRouter as Router, Switch } from 'react-router-dom';
import Ibaseshop from './ibaseshopLogo.png';

import { makeStyles } from '@material-ui/core/styles';

import InputLabel from '@material-ui/core/InputLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';

import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import PopupState, { bindTrigger, bindMenu } from 'material-ui-popup-state';




// import {DataContext} from './component/Data'

import {Data} from './component/Data';


import ApiService from "./ApiService";

import Home from './component/home';
import Footer from './component/footer';
import Profile from './component/profile';
import Search from './component/search';
import Product from './component/product';
import AddItem from './component/additem';
import SignIn from './component/signIn';
import SignUp from './component/signUp';
import NavBar from './component/appBar';
import CreateShop from './component/createShop';
import EditShop from './component/editShop';

import Payment from './component/Payment';
import BuyingThings from './component/BuyingThings';
import Shop from './component/ShopSide';
import Buynow from './component/buyNow';
import MyOrder from './component/myOrder';





import Admin from './component/admin/admin';
import ShopDetails from './component/admin/shopDetails';
import AdminShopEdite from './component/admin/adminShopEdite';
import UserDetails from './component/admin/userDetails';
import EditUser from './component/admin/editUser';
import ProductDetails from './component/admin/productDetails';
import EditProduct from './component/editProduct';
import OrderDetails from './component/admin/orderDetails';
import EditOrder from './component/admin/editOrder';
import AddOrder from './component/admin/addOrders';
import Cart from './component/cart';
import AllShop from './component/allShop';










//import PicUploadNoCrop from './component/imgCrop';





class App extends Component {


  constructor(props){
    super(props);
    this.state = {
      searchKey:'',
      locationSelectDiv:'show',
      currentUser: undefined,
      logIn:false,
      shopId:'',
      shopName:'',
      admin:'',
      showAdminBoard:'',
      roles:[],
      products:[],

      cartNo:localStorage.getItem("cartNo"),
    };
  }

  componentDidMount(){

    const authResult = new URLSearchParams(window.location.search);
    const searchKey = authResult.get('searchKey');

    let user = localStorage.getItem("user");
    if (localStorage.getItem('userName')) {

      this.setState({
        currentUser: user,
        logIn:true,
        searchKey:searchKey,
         admin:localStorage.getItem("admin"),
      //  showAdminBoard: user.roles.includes("ROLE_ADMIN")
        //roles:user.roles,
      });
    }

    this.loadShop()


  };


  loadShop = () => {
    ApiService.getShopByUserId(localStorage.getItem("userId"))
    .then(res => {
        const shop = res.data;
        this.setState({
            shopId:res.data.shopId,
            shopName:res.data.shopName,
        })
    })
  }





  onChangeSearch = (e) =>{
    this.setState({
      searchKey:e.target.value,
    })
  }


  logOut = () => {
      localStorage.clear();
      window.location.href='/';
      window.location.reload();
    }


    static contextType = Data;




  render() {

      const {addCart,cart,buythins,cartNo,total} = this.context;

      const { currentUser } = this.state;
      const products = this.state.products;



    return (
      <Router>
      <Data>
          <div className="App">


            <NavBar/>

            <div className='switchDiv' style={{ minHeight: `${window.innerHeight-400}px`,marginTop:'65px' }}>

              <Switch>
                <Route exact path={["/", "/home"]} component={Home} />
                <Route exact path={["/profile"]} component={Profile} />
                <Route exact path={["/search"]} component={Search} />
                <Route exact path={["/product/:id"]} component={Product} />
                <Route exact path={["/additem/:id"]} component={AddItem} />
                <Route exact path={["/signIn"]} component={SignIn} />
                <Route exact path={["/signUp"]} component={SignUp} />

                <Route exact path={["/createShop"]} component={CreateShop} />
                <Route exact path={["/editShop/:id"]} component={EditShop} />
                <Route exact path={["/shop/:id"]} component={Shop} />
                <Route exact path={["/buynow"]} component={Buynow} />
                <Route exact path={["/myorder"]} component={MyOrder} />



                <Route exact path={["/admin"]} component={Admin} />
                <Route exact path={["/shopDetails"]} component={ShopDetails} />
                <Route exact path={["/adminShopEdite/:id"]} component={AdminShopEdite} />
                <Route exact path={["/userDetails"]} component={UserDetails} />
                <Route exact path={["/editUser/:id"]} component={EditUser} />
                <Route exact path={["/productDetails"]} component={ProductDetails} />
                <Route exact path={["/editProduct/:id"]} component={EditProduct} />
                <Route exact path={["/orderDetails"]} component={OrderDetails} />
                <Route exact path={["/editOrder/:id"]} component={EditOrder} />
                <Route exact path={["/addOrder"]} component={AddOrder} />
                <Route exact path={["/cart"]} component={Cart} />
                <Route exact path={["/payment"]} component={Payment} />
                <Route exact path={["/allShop"]} component={AllShop} />










              </Switch>

            </div>
            <Footer/>


        </div>
      </Data>
    </Router>
    );
  }
}

export default App;
